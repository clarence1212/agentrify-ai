"""Information barriers, enforced in code rather than by convention.

A `View` is the only thing a role receives. It contains exactly the fields that
role is allowed to see. Attempting to read anything else raises.

  Proposer : surface + train-set failures. Never held-out, adversarial, judge rationale.
  Critic   : proposal diff + surface. Never held-out.
  Judge    : proposal diff + metric scores. Never the proposer's rationale.
  Auditor  : everything, read-only.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


class BarrierViolation(PermissionError):
    pass


@dataclass
class View:
    role: str
    _data: dict[str, Any] = field(default_factory=dict, repr=False)
    _allowed: frozenset = field(default=frozenset(), repr=False)

    def __getitem__(self, key: str) -> Any:
        if key not in self._allowed:
            raise BarrierViolation(f"{self.role} attempted to read '{key}' across an information barrier")
        return self._data[key]

    def get(self, key: str, default: Any = None) -> Any:
        return self[key] if key in self._allowed and key in self._data else default


ALLOW = {
    "proposer": frozenset({"surface", "train_failures", "change_class", "surface_item", "policy_max_diff"}),
    "critic":   frozenset({"surface", "proposal", "change_class"}),
    "judge":    frozenset({"proposal_diff", "scores_before", "scores_after", "metrics", "adversarial_failures"}),
    "auditor":  frozenset({"surface", "proposal", "proposal_diff", "scores_before", "scores_after", "metrics",
                           "train_failures", "adversarial_failures", "rationale", "judge_rationale",
                           "frozen_violations", "lineage"}),
}


def view_for(role: str, **data: Any) -> View:
    if role not in ALLOW:
        raise ValueError(role)
    return View(role=role, _data=data, _allowed=ALLOW[role])
