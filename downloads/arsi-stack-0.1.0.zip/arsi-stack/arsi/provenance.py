"""Append-only provenance log. Every proposal, score, verdict and promotion is recorded.

Lineage: each promoted change records its parent surface hash, so the auditor can
reconstruct how any deployed component came to be.
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Iterator


class Provenance:
    def __init__(self, state_dir: Path):
        self.path = state_dir / "provenance.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def record(self, event: str, **data: Any) -> dict[str, Any]:
        row = {"ts": time.time(), "event": event, **data}
        with self.path.open("a") as f:
            f.write(json.dumps(row, sort_keys=True) + "\n")
        return row

    def events(self) -> Iterator[dict[str, Any]]:
        if not self.path.exists():
            return iter(())
        return (json.loads(l) for l in self.path.read_text().splitlines() if l.strip())

    def lineage(self, surface_hash: str) -> list[dict[str, Any]]:
        """Walk promoted changes backwards from a surface hash."""
        promos = {e["new_hash"]: e for e in self.events() if e["event"] == "promoted"}
        chain, h = [], surface_hash
        while h in promos:
            chain.append(promos[h])
            h = promos[h]["parent_hash"]
        return chain

    def clean_promotions(self, change_class: str) -> int:
        """Promotions of this class not later rolled back."""
        rolled = {e["from_hash"] for e in self.events() if e["event"] == "rolled_back"}
        return sum(1 for e in self.events()
                   if e["event"] == "promoted" and e["change_class"] == change_class
                   and e["new_hash"] not in rolled)
