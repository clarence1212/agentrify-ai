"""Frozen evaluator. Lives under a frozen path; hash-verified before every cycle.

The application supplies one function:
    score(surface: dict[str,str], cases: list[dict]) -> dict[str, float]
returning a value per declared metric. The evaluator runs it on train (for the proposer's
feedback), held-out (for the verdict) and adversarial (for the critic) sets, and applies the
acceptance rule. The acceptance rule is code here, not a model.
"""
from __future__ import annotations

import importlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .config import AppConfig, MetricSpec


@dataclass
class Verdict:
    accepted: bool
    reasons: list[str]
    before: dict[str, float]
    after: dict[str, float]


def _load_fn(spec: str) -> Callable:
    mod, fn = spec.split(":")
    return getattr(importlib.import_module(mod), fn)


def _cases(p: Path) -> list[dict[str, Any]]:
    return [json.loads(l) for l in p.read_text().splitlines() if l.strip()]


class Evaluator:
    def __init__(self, cfg: AppConfig):
        self.cfg = cfg
        self.score_fn = _load_fn(cfg.evaluator.module)
        self.metrics: list[MetricSpec] = cfg.evaluator.metrics

    def run(self, surface: dict[str, str], which: str) -> dict[str, float]:
        p = {"train": self.cfg.evaluator.train_set, "heldout": self.cfg.evaluator.heldout_set,
             "adversarial": self.cfg.evaluator.adversarial_set}[which]
        return self.score_fn(surface, _cases(self.cfg.root / p))

    def failures(self, surface: dict[str, str], which: str) -> list[dict[str, Any]]:
        """Per-case failures, for the proposer (train) or critic (adversarial). Never held-out."""
        if which == "heldout":
            raise PermissionError("held-out failures are never exposed")
        p = {"train": self.cfg.evaluator.train_set, "adversarial": self.cfg.evaluator.adversarial_set}[which]
        cases = _cases(self.cfg.root / p)
        fail_fn = getattr(importlib.import_module(self.cfg.evaluator.module.split(":")[0]), "failures", None)
        return fail_fn(surface, cases) if fail_fn else []

    def failures_on(self, surface: dict[str, str], cases: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Failures on an ad-hoc case list (e.g. cases the critic just wrote)."""
        if not cases:
            return []
        fail_fn = getattr(importlib.import_module(self.cfg.evaluator.module.split(":")[0]), "failures", None)
        return fail_fn(surface, cases) if fail_fn else []

    # ---- the acceptance rule: every primary improves, no guard regresses, on held-out ----
    def judge(self, before: dict[str, float], after: dict[str, float]) -> Verdict:
        reasons: list[str] = []
        ok = True
        for m in self.metrics:
            b, a = before[m.name], after[m.name]
            delta = (a - b) if m.direction == "higher" else (b - a)
            if m.kind == "primary":
                if delta < m.min_effect:
                    ok = False
                    reasons.append(f"primary '{m.name}' improved {delta:+.4f} < min_effect {m.min_effect}")
                else:
                    reasons.append(f"primary '{m.name}' {b:.4f} -> {a:.4f} ok")
            else:
                if delta < -m.tolerance:
                    ok = False
                    reasons.append(f"guard '{m.name}' regressed {delta:+.4f} beyond tolerance {m.tolerance}")
                else:
                    reasons.append(f"guard '{m.name}' {b:.4f} -> {a:.4f} held")
        return Verdict(accepted=ok, reasons=reasons, before=before, after=after)
