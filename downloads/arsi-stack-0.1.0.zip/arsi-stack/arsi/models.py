"""Model providers. One interface, several backends.

`mock` runs offline so the whole loop can be exercised without keys.
Real providers are thin: install the SDK, set the env var, change `provider:` in arsi.yaml.
"""
from __future__ import annotations

import os
import random
from typing import Protocol

from .config import ModelSpec


class LLM(Protocol):
    spec: ModelSpec
    def complete(self, system: str, user: str, temperature: float = 0.0) -> str: ...


class MockLLM:
    """Deterministic stand-in. Behaviour is driven by the application's own mock hooks
    (see examples/support_triage/app.py) so the loop has something real to optimise."""
    def __init__(self, spec: ModelSpec):
        self.spec = spec
        self.rng = random.Random(hash(spec.model) & 0xFFFF)

    def complete(self, system: str, user: str, temperature: float = 0.0) -> str:
        # The example app registers a handler; fall back to echo.
        handler = _MOCK_HANDLERS.get(self.spec.model)
        if handler:
            # deterministic for a given (model, input): same surface -> same proposal, new surface -> new draw
            rng = random.Random(f"{self.spec.model}:{user}") if temperature > 0 else None
            return handler(system, user, rng)
        return user


_MOCK_HANDLERS: dict = {}


def register_mock(model_id: str, handler) -> None:
    _MOCK_HANDLERS[model_id] = handler


class AnthropicLLM:
    def __init__(self, spec: ModelSpec):
        import anthropic  # type: ignore
        self.spec = spec
        self.client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

    def complete(self, system: str, user: str, temperature: float = 0.0) -> str:
        r = self.client.messages.create(model=self.spec.model, max_tokens=2048, temperature=temperature,
                                        system=system, messages=[{"role": "user", "content": user}])
        return r.content[0].text


class OpenAILLM:
    def __init__(self, spec: ModelSpec):
        from openai import OpenAI  # type: ignore
        self.spec = spec
        self.client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

    def complete(self, system: str, user: str, temperature: float = 0.0) -> str:
        r = self.client.chat.completions.create(model=self.spec.model, temperature=temperature,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}])
        return r.choices[0].message.content or ""


class OllamaLLM:
    def __init__(self, spec: ModelSpec):
        import ollama  # type: ignore
        self.spec = spec
        self.client = ollama

    def complete(self, system: str, user: str, temperature: float = 0.0) -> str:
        r = self.client.chat(model=self.spec.model, options={"temperature": temperature},
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}])
        return r["message"]["content"]


PROVIDERS = {"mock": MockLLM, "anthropic": AnthropicLLM, "openai": OpenAILLM, "ollama": OllamaLLM}


def build(spec: ModelSpec) -> LLM:
    if spec.provider not in PROVIDERS:
        raise ValueError(f"unknown provider '{spec.provider}'; known: {sorted(PROVIDERS)}")
    return PROVIDERS[spec.provider](spec)
