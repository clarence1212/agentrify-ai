"""Configuration schema for an A-RSI application.

One arsi.yaml per application. Every component reads only its own section.
Validation is strict: a config that violates a structural safety rule is refused,
so a misconfigured loop cannot start.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


class ConfigError(ValueError):
    pass


@dataclass
class ModelSpec:
    provider: str          # mock | anthropic | openai | ollama | ...
    family: str            # vendor/model family, used for the independence rule
    model: str             # concrete model id
    role_note: str = ""


@dataclass
class Roles:
    proposer: ModelSpec
    judge: ModelSpec
    critic: ModelSpec
    auditor: ModelSpec
    ensemble_judges: list[ModelSpec] = field(default_factory=list)


@dataclass
class MetricSpec:
    name: str
    kind: str              # primary | guard
    direction: str         # higher | lower
    min_effect: float = 0.0     # primary: minimum absolute improvement to accept
    tolerance: float = 0.0      # guard: maximum allowed regression


@dataclass
class EvaluatorSpec:
    module: str            # python path "pkg.mod:function" producing scores
    train_set: str
    heldout_set: str
    adversarial_set: str
    refresh_every_cycles: int = 5
    metrics: list[MetricSpec] = field(default_factory=list)


@dataclass
class SurfaceItem:
    name: str
    path: str
    change_class: str      # prompt | retrieval | skill | tool | adapter | topology


@dataclass
class ChangeClassPolicy:
    name: str
    initial_gate: str      # human | auto
    autonomy_after: int    # clean promotions needed before auto (0 = never auto, -1 = already)
    max_diff_chars: int
    stages: list[str] = field(default_factory=lambda: ["shadow", "canary", "partial", "full"])


@dataclass
class Bounds:
    proposals_per_cycle: int = 4
    lineage_depth: int = 5
    max_cycles_without_human: int = 10


@dataclass
class AppConfig:
    name: str
    description: str
    roles: Roles
    evaluator: EvaluatorSpec
    surface: list[SurfaceItem]
    change_classes: dict[str, ChangeClassPolicy]
    bounds: Bounds
    frozen_paths: list[str]
    state_dir: str = ".arsi"
    root: Path = field(default=Path("."))

    # ---- structural safety rules, checked at load ----
    def validate(self) -> list[str]:
        problems: list[str] = []
        r = self.roles
        if r.proposer.family == r.judge.family:
            problems.append("roles: proposer and judge share a model family; independence rule violated")
        if r.proposer.family == r.critic.family:
            problems.append("roles: proposer and critic share a model family; critic can be learned")
        if not self.surface:
            problems.append("surface: empty; nothing for the loop to improve")
        for s in self.surface:
            if s.change_class not in self.change_classes:
                problems.append(f"surface: '{s.name}' has unknown change_class '{s.change_class}'")
            if any(Path(s.path) == Path(fp) or Path(fp) in Path(s.path).parents for fp in self.frozen_paths):
                problems.append(f"surface: '{s.name}' at {s.path} overlaps a frozen path")
        kinds = {m.kind for m in self.evaluator.metrics}
        if "primary" not in kinds:
            problems.append("evaluator: no primary metric declared")
        if "guard" not in kinds:
            problems.append("evaluator: no guard metric declared; Goodhart defence missing")
        for p in (self.evaluator.heldout_set, self.evaluator.adversarial_set):
            if not any(Path(p) == Path(fp) or Path(fp) in Path(p).parents for fp in self.frozen_paths):
                problems.append(f"evaluator: '{p}' is not under a frozen path; proposer could read it")
        for cc in self.change_classes.values():
            if cc.name in ("tool", "adapter", "topology") and cc.autonomy_after not in (0,):
                problems.append(f"change_classes: '{cc.name}' must stay human-gated (autonomy_after: 0)")
        return problems


def _model(d: dict[str, Any]) -> ModelSpec:
    return ModelSpec(provider=d["provider"], family=d["family"], model=d["model"], role_note=d.get("role_note", ""))


def load(path: str | Path) -> AppConfig:
    path = Path(path)
    raw = yaml.safe_load(path.read_text())
    try:
        roles = Roles(
            proposer=_model(raw["roles"]["proposer"]),
            judge=_model(raw["roles"]["judge"]),
            critic=_model(raw["roles"]["critic"]),
            auditor=_model(raw["roles"]["auditor"]),
            ensemble_judges=[_model(m) for m in raw["roles"].get("ensemble_judges", [])],
        )
        ev = raw["evaluator"]
        evaluator = EvaluatorSpec(
            module=ev["module"], train_set=ev["train_set"], heldout_set=ev["heldout_set"],
            adversarial_set=ev["adversarial_set"], refresh_every_cycles=ev.get("refresh_every_cycles", 5),
            metrics=[MetricSpec(**m) for m in ev["metrics"]],
        )
        surface = [SurfaceItem(**s) for s in raw["surface"]]
        ccs = {c["name"]: ChangeClassPolicy(**c) for c in raw["change_classes"]}
        bounds = Bounds(**raw.get("bounds", {}))
        cfg = AppConfig(
            name=raw["name"], description=raw.get("description", ""), roles=roles, evaluator=evaluator,
            surface=surface, change_classes=ccs, bounds=bounds, frozen_paths=raw["frozen_paths"],
            state_dir=raw.get("state_dir", ".arsi"), root=path.parent,
        )
    except KeyError as e:
        raise ConfigError(f"missing key in {path}: {e}") from e
    problems = cfg.validate()
    if problems:
        raise ConfigError("config refused:\n  - " + "\n  - ".join(problems))
    return cfg
