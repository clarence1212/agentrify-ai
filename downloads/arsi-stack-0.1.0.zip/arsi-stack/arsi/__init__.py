"""A-RSI: Application-scoped Recursive Self-Improvement reference stack.

Three bands, enforced in code:
  - frozen core      : evaluator, safety policy, held-out sets, provenance (hash-checked, loop cannot write)
  - mutable periphery: prompts, tools, skills, retrieval, adapters (the declared surface, the only thing that changes)
  - governance       : deterministic governor (budgets, change classes, staging, rollback), auditor

Everything is driven by one arsi.yaml produced by `arsi init`.
"""
__version__ = "0.1.0"
