"""Mutable surface and frozen core: what may change, what may not, and how we know.

The frozen core is protected by content hashes recorded at `arsi init` / `arsi seal`.
Before every cycle the hashes are re-verified; a mismatch halts the loop.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .config import AppConfig


def file_hash(p: Path) -> str:
    h = hashlib.sha256()
    if p.is_dir():
        for f in sorted(x for x in p.rglob("*") if x.is_file()):
            h.update(f.relative_to(p).as_posix().encode())
            h.update(f.read_bytes())
    else:
        h.update(p.read_bytes())
    return h.hexdigest()


def seal_frozen(cfg: AppConfig) -> dict[str, str]:
    """Record hashes of every frozen path. Called once by a human; never by the loop."""
    hashes = {fp: file_hash(cfg.root / fp) for fp in cfg.frozen_paths}
    out = cfg.root / cfg.state_dir / "frozen.lock"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(hashes, indent=2))
    return hashes


def verify_frozen(cfg: AppConfig) -> list[str]:
    """Return a list of frozen paths whose content changed since sealing."""
    lock = cfg.root / cfg.state_dir / "frozen.lock"
    if not lock.exists():
        return ["<no frozen.lock; run `arsi seal`>"]
    expected = json.loads(lock.read_text())
    bad = []
    for fp, h in expected.items():
        p = cfg.root / fp
        if not p.exists() or file_hash(p) != h:
            bad.append(fp)
    for fp in cfg.frozen_paths:
        if fp not in expected:
            bad.append(f"{fp} (unsealed)")
    return bad


def read_surface(cfg: AppConfig) -> dict[str, str]:
    """Current content of every mutable surface item (text files only in this reference stack)."""
    return {s.name: (cfg.root / s.path).read_text() for s in cfg.surface}


def write_surface_item(cfg: AppConfig, name: str, content: str) -> Path:
    item = next(s for s in cfg.surface if s.name == name)
    p = cfg.root / item.path
    p.write_text(content)
    return p


def surface_hash(cfg: AppConfig) -> str:
    return hashlib.sha256(json.dumps(read_surface(cfg), sort_keys=True).encode()).hexdigest()[:12]
