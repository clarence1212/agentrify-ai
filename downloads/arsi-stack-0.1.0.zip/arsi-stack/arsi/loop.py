"""One A-RSI cycle. Reads like the diagram: periphery -> core -> governance -> periphery."""
from __future__ import annotations

import json
from dataclasses import asdict

from . import models
from .barriers import view_for
from .config import AppConfig
from .evaluator import Evaluator
from .governor import Governor
from .provenance import Provenance
from .roles import Auditor, Critic, Judge, Proposer
from .surface import read_surface, surface_hash, verify_frozen


def run_cycle(cfg: AppConfig, log=print) -> dict:
    prov = Provenance(cfg.root / cfg.state_dir)
    gov = Governor(cfg, prov)
    ev = Evaluator(cfg)

    # 0. frozen-core invariant: a mismatch halts, it does not warn
    bad = verify_frozen(cfg)
    if bad:
        prov.record("halted", reason="frozen core modified", paths=bad)
        raise SystemExit(f"HALT: frozen core modified: {bad}. Re-seal only after human review.")

    proposer = Proposer(models.build(cfg.roles.proposer))
    critic = Critic(models.build(cfg.roles.critic))
    judge = Judge(models.build(cfg.roles.judge))
    auditor = Auditor()

    cycle_no = sum(1 for e in prov.events() if e["event"] == "cycle_start") + 1
    prov.record("cycle_start", cycle=cycle_no, surface_hash=surface_hash(cfg))
    log(f"cycle {cycle_no}  surface {surface_hash(cfg)}")

    surface = read_surface(cfg)
    before = ev.run(surface, "heldout")
    train_fail = ev.failures(surface, "train")
    log(f"  baseline held-out: {json.dumps(before)}   train failures: {len(train_fail)}")

    cycles_since_human = 0
    for e in reversed(list(prov.events())):
        if e["event"] in ("promoted",) and "approved" in e.get("note", ""):
            break
        if e["event"] == "cycle_start":
            cycles_since_human += 1

    results = []
    budget = cfg.bounds.proposals_per_cycle
    for item in cfg.surface:
        if budget == 0:
            break
        pol = cfg.change_classes[item.change_class]
        budget -= 1

        # 1. propose (sees surface + train failures only)
        p = proposer.propose(view_for("proposer", surface=surface, train_failures=train_fail,
                                      surface_item=item.name, change_class=item.change_class,
                                      policy_max_diff=pol.max_diff_chars))
        if p.after.strip() == p.before.strip():
            log(f"  {item.name}: proposer made no change")
            continue
        prov.record("proposed", surface_item=item.name, change_class=item.change_class, diff_chars=p.diff_chars)

        # 2. critic attacks (sees proposal, never held-out)
        extra = critic.attack(view_for("critic", surface=surface, proposal=p, change_class=item.change_class))
        candidate = dict(surface); candidate[item.name] = p.after
        adv_fail = ev.failures(candidate, "adversarial") + ev.failures_on(candidate, extra)

        # 3. evaluator scores on held-out, applies the acceptance rule (code)
        after = ev.run(candidate, "heldout")
        verdict = ev.judge(before, after)

        # 4. judge reviews the diff, blind to rationale; may only veto
        judge_ok, judge_note = judge.review(view_for("judge", proposal_diff=p.diff, scores_before=before,
                                                     scores_after=after, metrics=[m.name for m in ev.metrics],
                                                     adversarial_failures=adv_fail))

        # 5. auditor invariants
        findings = auditor.check(view_for("auditor", proposal=p, frozen_violations=verify_frozen(cfg),
                                          lineage=prov.lineage(surface_hash(cfg)), lineage_limit=cfg.bounds.lineage_depth,
                                          surface=surface, proposal_diff=p.diff, scores_before=before, scores_after=after,
                                          metrics=[m.name for m in ev.metrics], train_failures=train_fail,
                                          adversarial_failures=adv_fail, rationale=p.rationale, judge_rationale=judge_note))

        # 6. governor decides; it is the only writer
        d = gov.decide(item.change_class, p.diff_chars, verdict.accepted, judge_ok, findings, cycles_since_human)
        prov.record("verdict", surface_item=item.name, accepted=verdict.accepted, judge_ok=judge_ok,
                    findings=findings, decision=d.stage, reasons=d.reasons + verdict.reasons,
                    before=before, after=after, diff_chars=p.diff_chars)
        log(f"  {item.name}: diff {p.diff_chars} chars | held-out {json.dumps(after)} | {d.stage}")
        for r in verdict.reasons + d.reasons:
            log(f"      - {r}")

        if d.promote:
            h = gov.promote(item.name, p.after, item.change_class, d.stage)
            surface = read_surface(cfg); before = after
            log(f"      promoted -> {h} ({d.stage})")
        elif d.needs_human:
            gov.queue_for_human(item.name, p.after, item.change_class, asdict(verdict))
            log("      queued for human approval (`arsi pending`, `arsi approve N`)")
        results.append({"item": item.name, "decision": d.stage, "after": after})

    prov.record("cycle_end", cycle=cycle_no, surface_hash=surface_hash(cfg))
    return {"cycle": cycle_no, "results": results}
