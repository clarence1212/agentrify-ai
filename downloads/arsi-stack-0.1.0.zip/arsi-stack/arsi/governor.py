"""The Governor: deterministic code, no model. Owns budgets, staging, promotion and rollback.

It is the only component that writes to the mutable surface, and it does so only after:
  1. frozen core verified          (surface.verify_frozen)
  2. evaluator acceptance rule met (evaluator.judge)
  3. judge did not veto            (roles.Judge)
  4. auditor found nothing         (roles.Auditor)
  5. change-class gate satisfied   (human sign-off or earned autonomy)
  6. magnitude bound satisfied     (diff <= max_diff_chars)
"""
from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path

from .config import AppConfig
from .provenance import Provenance
from .surface import read_surface, surface_hash, write_surface_item


@dataclass
class Decision:
    promote: bool
    stage: str
    reasons: list[str] = field(default_factory=list)
    needs_human: bool = False


class Governor:
    def __init__(self, cfg: AppConfig, prov: Provenance):
        self.cfg = cfg
        self.prov = prov
        self.state_dir = cfg.root / cfg.state_dir
        self.snap_dir = self.state_dir / "snapshots"
        self.snap_dir.mkdir(parents=True, exist_ok=True)
        self.pending = self.state_dir / "pending_human.jsonl"

    # ---- gates ----
    def gate(self, change_class: str) -> str:
        pol = self.cfg.change_classes[change_class]
        if pol.autonomy_after == 0 or pol.initial_gate == "human" and self.prov.clean_promotions(change_class) < pol.autonomy_after:
            return "human"
        return "auto"

    def decide(self, change_class: str, diff_chars: int, accepted: bool, judge_ok: bool,
               audit_findings: list[str], cycles_since_human: int) -> Decision:
        pol = self.cfg.change_classes[change_class]
        reasons = []
        if diff_chars > pol.max_diff_chars:
            reasons.append(f"magnitude {diff_chars} > max_diff_chars {pol.max_diff_chars}")
        if not accepted:
            reasons.append("evaluator acceptance rule not met")
        if not judge_ok:
            reasons.append("judge veto")
        if audit_findings:
            reasons.append("auditor findings: " + "; ".join(audit_findings))
        if reasons:
            return Decision(False, "rejected", reasons)
        if cycles_since_human >= self.cfg.bounds.max_cycles_without_human:
            return Decision(False, "held", ["max_cycles_without_human reached"], needs_human=True)
        if self.gate(change_class) == "human":
            return Decision(False, "pending_human", ["change class is human-gated"], needs_human=True)
        return Decision(True, pol.stages[0], ["all gates passed; auto-promoting to first stage"])

    # ---- writes (the only writer of the surface) ----
    def snapshot(self) -> str:
        h = surface_hash(self.cfg)
        d = self.snap_dir / h
        if not d.exists():
            d.mkdir()
            for s in self.cfg.surface:
                shutil.copy(self.cfg.root / s.path, d / s.name)
        return h

    def promote(self, item: str, content: str, change_class: str, stage: str, note: str = "") -> str:
        parent = self.snapshot()
        write_surface_item(self.cfg, item, content)
        new = self.snapshot()
        self.prov.record("promoted", surface_item=item, change_class=change_class, stage=stage,
                         parent_hash=parent, new_hash=new, note=note)
        return new

    def rollback(self, to_hash: str | None = None) -> str:
        promos = [e for e in self.prov.events() if e["event"] == "promoted"]
        if not promos:
            raise RuntimeError("nothing to roll back")
        target = to_hash or promos[-1]["parent_hash"]
        d = self.snap_dir / target
        if not d.exists():
            raise RuntimeError(f"no snapshot {target}")
        cur = surface_hash(self.cfg)
        for s in self.cfg.surface:
            shutil.copy(d / s.name, self.cfg.root / s.path)
        self.prov.record("rolled_back", from_hash=cur, to_hash=target)
        return target

    # ---- human queue ----
    def queue_for_human(self, item: str, content: str, change_class: str, verdict: dict) -> None:
        if any(p["surface_item"] == item and p["content"] == content for p in self.pending_items()):
            return  # identical proposal already waiting
        with self.pending.open("a") as f:
            f.write(json.dumps({"ts": time.time(), "surface_item": item, "change_class": change_class,
                                "content": content, "verdict": verdict}) + "\n")
        self.prov.record("queued_for_human", surface_item=item, change_class=change_class)

    def pending_items(self) -> list[dict]:
        if not self.pending.exists():
            return []
        return [json.loads(l) for l in self.pending.read_text().splitlines() if l.strip()]

    def approve(self, index: int, approver: str) -> str:
        items = self.pending_items()
        it = items.pop(index)
        self.pending.write_text("".join(json.dumps(x) + "\n" for x in items))
        return self.promote(it["surface_item"], it["content"], it["change_class"],
                            self.cfg.change_classes[it["change_class"]].stages[0], note=f"approved by {approver}")
