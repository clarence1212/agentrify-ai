"""arsi command line.

  arsi init [dir]        guided walkthrough -> arsi.yaml + folder skeleton
  arsi check [dir]       validate config, verify frozen core, dry-run the evaluator
  arsi seal [dir]        (human) record frozen-core hashes
  arsi cycle [dir] [-n]  run N improvement cycles
  arsi pending [dir]     list proposals waiting for human approval
  arsi approve [dir] N   (human) promote pending proposal N
  arsi rollback [dir]    revert the last promotion (or --to HASH)
  arsi status [dir]      surface hash, autonomy per change class, recent events
  arsi matrix [dir]      print the control matrix with live evidence pointers
"""
from __future__ import annotations

import argparse
import json
import sys
import textwrap
from pathlib import Path

import yaml

from . import config as cfgmod
from .evaluator import Evaluator
from .governor import Governor
from .loop import run_cycle
from .provenance import Provenance
from .surface import read_surface, seal_frozen, surface_hash, verify_frozen

CHANGE_CLASS_DEFAULTS = [
    # name, initial_gate, autonomy_after, max_diff_chars
    ("prompt", "human", 3, 1500),
    ("retrieval", "human", 3, 4000),
    ("skill", "human", 5, 3000),
    ("tool", "human", 0, 2000),
    ("adapter", "human", 0, 0),
    ("topology", "human", 0, 0),
]

FAMILIES = {
    "1": ("anthropic", "anthropic", "claude-sonnet-4-5"),
    "2": ("openai", "openai", "gpt-4.1"),
    "3": ("ollama", "llama", "llama3.1"),
    "4": ("mock", "mock-a", "mock-proposer"),
}


def ask(q: str, default: str | None = None) -> str:
    s = f"{q}" + (f" [{default}]" if default else "") + ": "
    a = input(s).strip()
    return a or (default or "")


def pick_model(role: str, hint: str, default_key: str, exclude_families: set[str]) -> dict:
    print(f"\n  {role.upper()} - {hint}")
    for k, (prov, fam, model) in FAMILIES.items():
        flag = "  (same family as another role: not allowed)" if fam in exclude_families else ""
        print(f"    {k}) {prov:10s} {model}{flag}")
    while True:
        k = ask("  choose", default_key)
        if k in FAMILIES and FAMILIES[k][1] not in exclude_families:
            prov, fam, model = FAMILIES[k]
            model = ask("  model id", model)
            return {"provider": prov, "family": fam, "model": model}
        print("  independence rule: proposer, judge and critic must be on different model families")


def cmd_init(args):
    root = Path(args.dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    print(textwrap.dedent(f"""
    A-RSI setup walkthrough  ->  {root}
    ------------------------------------------------------------
    Six steps. Each answer becomes a line in arsi.yaml you can edit later.
    Press Enter to accept a default.
    """))

    # 1 application
    print("STEP 1/6  The application")
    name = ask("  short name (slug)", root.name)
    desc = ask("  one line: what does this application do")
    print("\n  Fast feedback check: can 'better' be scored on held-out cases within hours?")
    fast = ask("  (y/n)", "y").lower().startswith("y")
    if not fast:
        print("  WARNING: slow feedback starves the loop. Scope the evaluator to an intermediate step with fast ground truth.")

    # 2 mutable surface
    print("\nSTEP 2/6  The mutable surface (what the loop MAY change)")
    print("  Each item: a text file the loop can rewrite, and its change class.")
    print("  Classes: " + ", ".join(c[0] for c in CHANGE_CLASS_DEFAULTS))
    surface = []
    while True:
        n = ask("  item name (blank to finish)", "system_prompt" if not surface else "")
        if not n:
            break
        p = ask("  path (relative)", f"surface/{n}.txt")
        c = ask("  change class", "prompt")
        surface.append({"name": n, "path": p, "change_class": c})
        (root / p).parent.mkdir(parents=True, exist_ok=True)
        if not (root / p).exists():
            (root / p).write_text(f"# {n}\nYou are the {name} assistant.\n")

    # 3 evaluator
    print("\nSTEP 3/6  The evaluator (frozen core)")
    print("  You must supply: a score() function, and three case files (train, held-out, adversarial).")
    module = ask("  scoring module 'package.module:function'", "app:score")
    metrics = []
    print("  Primary metric(s): what must improve.")
    while True:
        m = ask("  primary metric name (blank to finish)", "accuracy" if not metrics else "")
        if not m:
            break
        eff = float(ask("  minimum improvement to accept (absolute)", "0.01"))
        metrics.append({"name": m, "kind": "primary", "direction": "higher", "min_effect": eff})
    print("  Guard metric(s): what must NOT regress (safety, compliance, cost...).")
    while True:
        m = ask("  guard metric name (blank to finish)", "policy_compliance" if len(metrics) == len([x for x in metrics if x['kind']=='primary']) else "")
        if not m:
            break
        d = ask("  direction (higher/lower is better)", "higher")
        tol = float(ask("  tolerance (max allowed regression)", "0.0"))
        metrics.append({"name": m, "kind": "guard", "direction": d, "tolerance": tol})
    refresh = int(ask("  refresh held-out set every N cycles", "5"))
    for sub in ("core/evals",):
        (root / sub).mkdir(parents=True, exist_ok=True)
    for f in ("train.jsonl", "heldout.jsonl", "adversarial.jsonl"):
        (root / "core/evals" / f).touch()
    if not (root / "app.py").exists():
        (root / "app.py").write_text(APP_STUB)

    # 4 roles
    print("\nSTEP 4/6  Roles and model families (independence rule enforced)")
    proposer = pick_model("proposer", "cheap, high volume", "4", set())
    judge = pick_model("judge", "different family, blind to rationale", "1", {proposer["family"]})
    critic = pick_model("critic", "rotated attacker", "2", {proposer["family"]})
    auditor = {"provider": "mock", "family": "none", "model": "deterministic"}

    # 5 bounds
    print("\nSTEP 5/6  Bounds")
    ppc = int(ask("  proposals per cycle", "4"))
    depth = int(ask("  lineage depth before human review", "5"))
    mcwh = int(ask("  max cycles without a human approval", "10"))

    # 6 change classes
    print("\nSTEP 6/6  Change-class policy (autonomy is earned per class)")
    ccs = []
    for n, gate, auto, mx in CHANGE_CLASS_DEFAULTS:
        if n in ("tool", "adapter", "topology"):
            print(f"  {n:9s} stays human-gated (autonomy_after: 0, max_diff {mx})")
            ccs.append({"name": n, "initial_gate": gate, "autonomy_after": 0, "max_diff_chars": mx})
            continue
        a = int(ask(f"  {n:9s} clean promotions before auto (0 = never)", str(auto)))
        m = int(ask(f"  {n:9s} max diff chars", str(mx)))
        ccs.append({"name": n, "initial_gate": gate, "autonomy_after": a, "max_diff_chars": m})

    cfg = {
        "name": name, "description": desc,
        "roles": {"proposer": proposer, "judge": judge, "critic": critic, "auditor": auditor},
        "evaluator": {"module": module, "train_set": "core/evals/train.jsonl", "heldout_set": "core/evals/heldout.jsonl",
                      "adversarial_set": "core/evals/adversarial.jsonl", "refresh_every_cycles": refresh, "metrics": metrics},
        "surface": surface, "change_classes": ccs,
        "bounds": {"proposals_per_cycle": ppc, "lineage_depth": depth, "max_cycles_without_human": mcwh},
        "frozen_paths": ["core", "app.py"], "state_dir": ".arsi",
    }
    (root / "arsi.yaml").write_text(yaml.safe_dump(cfg, sort_keys=False))
    print(textwrap.dedent(f"""
    Written {root/'arsi.yaml'}

    Next:
      1. Implement score() and failures() in {root/'app.py'}
      2. Fill core/evals/*.jsonl   (held-out and adversarial are under a frozen path on purpose)
      3. arsi seal {root}          (human: lock the frozen core)
      4. arsi check {root}
      5. arsi cycle {root}
    """))


def _load(args):
    return cfgmod.load(Path(args.dir) / "arsi.yaml")


def cmd_check(args):
    try:
        cfg = _load(args)
    except cfgmod.ConfigError as e:
        print(e); sys.exit(2)
    print(f"config ok: {cfg.name}")
    bad = verify_frozen(cfg)
    print("frozen core: " + ("verified" if not bad else f"PROBLEM {bad}"))
    sys.path.insert(0, str(cfg.root))
    ev = Evaluator(cfg)
    s = read_surface(cfg)
    for which in ("train", "heldout", "adversarial"):
        try:
            print(f"{which:11s} {json.dumps(ev.run(s, which))}")
        except Exception as e:  # noqa
            print(f"{which:11s} evaluator error: {e}")
    print(f"surface hash: {surface_hash(cfg)}")


def cmd_seal(args):
    cfg = _load(args)
    who = args.approver or input("your name (recorded in provenance): ").strip()
    h = seal_frozen(cfg)
    Provenance(cfg.root / cfg.state_dir).record("sealed", by=who, hashes=h)
    print(f"sealed {len(h)} frozen paths by {who}")


def cmd_cycle(args):
    cfg = _load(args)
    sys.path.insert(0, str(cfg.root))
    for _ in range(args.n):
        run_cycle(cfg)


def cmd_pending(args):
    cfg = _load(args)
    gov = Governor(cfg, Provenance(cfg.root / cfg.state_dir))
    items = gov.pending_items()
    if not items:
        print("nothing pending"); return
    for i, it in enumerate(items):
        v = it["verdict"]
        print(f"[{i}] {it['surface_item']} ({it['change_class']})  held-out {v['before']} -> {v['after']}")
        for r in v["reasons"]:
            print(f"      - {r}")


def cmd_approve(args):
    cfg = _load(args)
    gov = Governor(cfg, Provenance(cfg.root / cfg.state_dir))
    if args.index >= len(gov.pending_items()):
        print(f"no pending item {args.index}; run `arsi pending`"); sys.exit(1)
    who = args.approver or input("your name: ").strip()
    print("promoted ->", gov.approve(args.index, who))


def cmd_rollback(args):
    cfg = _load(args)
    gov = Governor(cfg, Provenance(cfg.root / cfg.state_dir))
    print("rolled back to", gov.rollback(args.to))


def cmd_status(args):
    cfg = _load(args)
    prov = Provenance(cfg.root / cfg.state_dir)
    gov = Governor(cfg, prov)
    print(f"{cfg.name}  surface {surface_hash(cfg)}  frozen {'ok' if not verify_frozen(cfg) else 'VIOLATED'}")
    print("autonomy by change class:")
    for n, pol in cfg.change_classes.items():
        clean = prov.clean_promotions(n)
        print(f"  {n:9s} gate={gov.gate(n):5s} clean_promotions={clean}  needs={pol.autonomy_after if pol.autonomy_after else 'never auto'}")
    print("recent events:")
    for e in list(prov.events())[-12:]:
        keys = {k: v for k, v in e.items() if k not in ("ts", "event", "hashes", "before", "after")}
        print(f"  {e['event']:16s} {json.dumps(keys)[:110]}")


MATRIX = [
    ("Loop modifies evaluator/policy", "frozen paths hash-verified each cycle", ".arsi/frozen.lock + 'halted' events"),
    ("Proposer and judge share blind spots", "independence rule in config.validate", "arsi.yaml roles.*.family"),
    ("Proposer argues judge into acceptance", "barriers.View: judge never sees rationale", "arsi/barriers.py ALLOW"),
    ("Score rises while quality falls", "acceptance rule on held-out only; refresh_every_cycles", "'verdict' events before/after"),
    ("Local gain breaks global constraint", "guard metrics with tolerance", "arsi.yaml evaluator.metrics kind=guard"),
    ("Unbounded/compounding change", "proposals_per_cycle, lineage_depth, max_diff_chars", "'verdict' events diff_chars; bounds"),
    ("Change cannot be undone", "snapshot per promotion; arsi rollback", ".arsi/snapshots/*, 'rolled_back' events"),
    ("Half-validated change propagates", "governor is sole writer; staged promotion", "'promoted' events stage"),
    ("No reconstruction of why", "append-only provenance; lineage()", ".arsi/provenance.jsonl"),
    ("Governor gamed", "governor is code outside the surface", "arsi/governor.py under version control"),
]


def cmd_matrix(args):
    print(f"{'Risk':40s} {'Control':52s} Evidence")
    for r, c, e in MATRIX:
        print(f"{r:40s} {c:52s} {e}")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="arsi", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name, fn in (("init", cmd_init), ("check", cmd_check), ("seal", cmd_seal), ("cycle", cmd_cycle),
                     ("pending", cmd_pending), ("approve", cmd_approve), ("rollback", cmd_rollback),
                     ("status", cmd_status), ("matrix", cmd_matrix)):
        p = sub.add_parser(name); p.set_defaults(fn=fn)
        p.add_argument("dir", nargs="?", default=".")
        if name == "cycle": p.add_argument("-n", type=int, default=1)
        if name == "approve": p.add_argument("index", type=int)
        if name in ("approve", "seal"): p.add_argument("--approver")
        if name == "rollback": p.add_argument("--to")
    a = ap.parse_args(argv)
    a.fn(a)


APP_STUB = '''"""Application hooks for A-RSI. This file is FROZEN (listed in frozen_paths): the loop cannot edit it.

score(surface, cases)    -> {metric_name: value} for every metric declared in arsi.yaml
failures(surface, cases) -> list of failing cases (shown to the proposer for train, critic for adversarial)

`surface` is {item_name: current_text}. Call your real application here.
"""

def run_app(surface: dict, case: dict) -> str:
    raise NotImplementedError("call your application with surface['system_prompt'] etc.")

def score(surface, cases):
    ok = sum(1 for c in cases if run_app(surface, c) == c["expected"])
    return {"accuracy": ok / max(len(cases), 1), "policy_compliance": 1.0}

def failures(surface, cases):
    return [dict(c, got=run_app(surface, c)) for c in cases if run_app(surface, c) != c["expected"]]
'''

if __name__ == "__main__":
    main()
