# A-RSI reference stack

Application-scoped Recursive Self-Improvement, as runnable code. The loop can improve an
application's prompts, skills, retrieval and small adapters, and is prevented in code from
touching anything else.

```
                 governance   Governor (code)  ·  Auditor (read-only)
                              budgets, change classes, staging, rollback
  ─────────────────────────── information barrier ───────────────────────────
                 frozen core  Evaluator + held-out sets + safety policy + provenance
                              hash-sealed by a human; a mismatch HALTS the loop
                              Judge (model B, blind)  ·  Critic (model C, rotated)
  ─────────────────────────── information barrier ───────────────────────────
         mutable periphery    Proposer (model A, cheap) → prompts · skills · retrieval · adapters
```

Each cycle: proposer drafts a change from train-set failures → critic attacks it →
evaluator scores it on held-out data and applies the acceptance rule (code) → judge may veto
(sees the diff, never the rationale) → auditor checks invariants → governor promotes, queues
for a human, or rejects. Everything is logged to an append-only provenance file.

## Quick start (runs offline, no keys)

```bash
pip install -e .                      # or: export PYTHONPATH=$PWD
E=examples/support_triage
arsi seal   $E --approver "you"       # human locks the frozen core
arsi check  $E                        # validate config, verify hashes, dry-run evaluator
arsi cycle  $E -n 3                   # proposals are queued: prompt class starts human-gated
arsi pending $E                       # inspect the queued proposal and its held-out scores
arsi approve $E 0 --approver "you"    # promote it
arsi cycle  $E -n 3                   # after 2 clean promotions the prompt class earns autonomy
arsi status $E                        # autonomy per class, recent events
arsi rollback $E                      # one-step revert of the last promotion
arsi matrix                           # control matrix with evidence pointers
```

On the bundled example, held-out accuracy moves from 0.34 to 0.93 over ~8 promotions while
both guard metrics hold, every promotion is human-gated until the class has earned autonomy,
and `rollback` restores the previous surface from a snapshot.

## Set up a new application: `arsi init`

```bash
arsi init my_app
```

Six steps, each answer becomes a line in `arsi.yaml`:

| Step | What you declare | Why it is a safety control |
| --- | --- | --- |
| 1 Application | name, description, fast-feedback check | A loop without fast ground truth optimises a proxy |
| 2 Mutable surface | each file the loop may rewrite + its change class | Everything not listed is frozen |
| 3 Evaluator | scoring module, primary metrics (+min effect), guard metrics (+tolerance), refresh cadence | Acceptance rule is multi-objective on held-out data only |
| 4 Roles | proposer / judge / critic model families | Independence rule: no two share a family (refused otherwise) |
| 5 Bounds | proposals per cycle, lineage depth, max cycles without a human | Bounds the recursion |
| 6 Change classes | clean promotions needed before auto; max diff chars | Autonomy is earned per class; tool/adapter/topology never go auto |

Then implement two functions in the generated `app.py` (frozen):

```python
def score(surface, cases) -> dict      # one value per declared metric
def failures(surface, cases) -> list   # failing cases, shown to proposer (train) and critic (adversarial)
```

and fill `core/evals/{train,heldout,adversarial}.jsonl`. Held-out lives under a frozen path
on purpose; `config.load` refuses a config where it doesn't.

## Going live

Change the three role lines in `arsi.yaml`:

```yaml
roles:
  proposer: {provider: openai,    family: openai,    model: gpt-4.1-mini}
  judge:    {provider: anthropic, family: anthropic, model: claude-sonnet-4-5}
  critic:   {provider: ollama,    family: llama,     model: llama3.1}
```

`pip install -e ".[anthropic,openai,ollama]"` and set the API keys. The loop is otherwise
unchanged. For a real application, `score()` calls your application with
`surface["system_prompt"]` etc. and compares with each case's `expected`.

## What is enforced in code (not by convention)

| Rule | Where |
| --- | --- |
| Proposer, judge, critic on different model families | `config.AppConfig.validate` |
| Held-out and adversarial sets under a frozen path | `config.AppConfig.validate` |
| tool / adapter / topology classes never auto-promote | `config.AppConfig.validate` |
| Frozen core hash-verified every cycle; mismatch halts | `surface.verify_frozen`, `loop.run_cycle` |
| Proposer cannot read held-out, judge rationale | `barriers.View` raises `BarrierViolation` |
| Judge cannot read proposer rationale | `barriers.ALLOW["judge"]` |
| Acceptance rule: all primaries improve, no guard regresses | `evaluator.Evaluator.judge` |
| Magnitude, rate, lineage, cycles-without-human bounds | `governor.Governor.decide` |
| Governor is the only writer of the surface | `governor.Governor.promote` |
| Every promotion snapshotted; one-step rollback | `governor.Governor.snapshot/rollback` |
| Append-only provenance with lineage | `provenance.Provenance` |

## Layout

```
arsi/
  config.py      schema + structural validation (refuses unsafe configs)
  surface.py     mutable surface, frozen-core sealing and verification
  evaluator.py   frozen evaluator and the acceptance rule
  barriers.py    information barriers as typed views
  models.py      providers: mock, anthropic, openai, ollama
  roles.py       Proposer, Critic, Judge, Auditor
  governor.py    deterministic governor: gates, budgets, promote, rollback, human queue
  provenance.py  append-only log, lineage, clean-promotion counts
  loop.py        one cycle
  cli.py         init walkthrough, check, seal, cycle, pending, approve, rollback, status, matrix
examples/support_triage/
  arsi.yaml      a complete config
  app.py         frozen hooks + offline mock roles
  surface/       the one mutable item
  core/evals/    train / heldout / adversarial cases
```

## Not in this reference stack

Staged traffic routing (shadow/canary/partial/full is recorded, not routed), evaluator
refresh automation, ensemble judging, and adapter training. Each has an obvious hook:
`Governor.promote` for routing, `Evaluator.run` for refresh, `roles.Judge` for ensembles.
